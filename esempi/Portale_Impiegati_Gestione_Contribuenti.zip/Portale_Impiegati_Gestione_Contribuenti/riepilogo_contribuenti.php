<!doctype html>
 	<html lang="it">
 	<head>
 		<!--[if IE]><script type="text/javascript">
 			(function() {
 				var baseTag = document.getElementsByTagName('base')[0];
 				baseTag.href = baseTag.href;
 			})();
 		</script><![endif]-->		
 		<title>Gestione Contribuenti</title>
 		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link rel="shortcut icon" href="static/img/logo_comune_di_bari.png" type="image/x-icon">
 		<link rel="stylesheet" href="static/css/bootstrap-italia_1.2.0.min.css" />
 		<link href="static/css/cagliari.min.css" rel="stylesheet" type="text/css" />
 		<link href="static/css/cagliari-print.min.css" rel="stylesheet" type="text/css" />		
 	</head>	
	<body class="push-body" data-ng-app="ponmetroca">
		<div class="body_wrapper push_container clearfix" id="page_top">
 			<!--[if lt IE 8]>
 				<p class="browserupgrade">È necessario aggiornare il browser</p>
 			<![endif]-->
 			<div class="skiplink sr-only">
 				<ul>
 					<li><a accesskey="2" href="index.html#main_container">Vai ai contenuti</a></li>
 					<li><a accesskey="3" href="index.html#menup">Vai al menu di navigazione</a></li>
 					<li><a accesskey="4" href="index.html#footer">Vai al footer</a></li>
 				</ul>
 			</div>		
			<header id="mainheader" class="navbar-fixed-top bg-blu container-fullwidth">
 				<!-- Fascia Appartenenza -->
 				<section class="preheader bg-bluscuro">
 					<div class="container">
 						<div class="row clearfix">
 							<div class="col-lg-12 col-md-12 col-sm-12 entesup">
 								<a aria-label="Collegamento a sito esterno - Sito del Comune di Bari - nuova finestra" title="Comune di Bari" href="https://www.comune.bari.it/" target="_blank">Comune di Bari</a>
 								<div class="float-right">
 									<!-- siti verticali -->
 									<div class="sitiverticali float-left text-right d-none d-xl-block d-lg-block">
										<a aria-label="Collegamento a sito esterno - Sito Regione Puglia - nuova finestra" title="Regione Puglia" href="https://www.regione.puglia.it/" target="_blank">Regione Puglia</a>
										<a aria-label="Collegamento a sito esterno - Sito Ufficio Rifiuti - nuova finestra" title="Ufficio Rifiuti" href="https://www.comune.bari.it/web/economia-tasse-e-tributi/trasparenza-gestione-rifiuti" target="_blank">Ufficio Rifiuti</a>
 									</div>
 									<!-- siti verticali -->
 									<!-- accedi -->
	 								<div class="accedi float-left text-right">									
											<a class="btn btn-default btn-accedi" target="_blank" href="https://www.comune.bari.it/accedi">
												<svg class="icon"><use xlink:href="static/img/ponmetroca.svg#ca-account_circle"></use></svg>
												<span>Nome Cognome</span>
											</a>
	 								</div>
 									<!-- accedi -->
								</div>
 							</div>
 						</div>
 					</div>               
 				</section>
 				<!-- Fascia Appartenenza -->	
				<!-- Button Menu -->
 				<button class="navbar-toggle menu-btn pull-left menu-left push-body jPushMenuBtn">
					<span class="sr-only">Toggle navigation</span>
					<span class="icon-bar icon-bar1"></span>
					<span class="icon-bar icon-bar2"></span>
					<span class="icon-bar icon-bar3"></span>
				</button>
				<!--End Button Menu -->
 
 				<!-- Menu -->
 				<nav class="cbp-spmenu cbp-spmenu-vertical cbp-spmenu-left" id="menup">
 					<div class="cbp-menu-wrapper clearfix">
						<div class="logo-burger">
 							<div class="logoimg-burger">
 								<a href="index.html" title="Portale Impiegati - Gestione Contribuenti"> 
 									<img src="static/img/logo_cagliari_print.svg" alt="Logo del Portale Impiegati - Gestione Contribuenti"/>
	 							</a>
 							</div>
 							<div class="logotxt-burger">
 								<a href="index.html" title="Portale Impiegati - Gestione Contribuenti">Portale Impiegati - Gestione Contribuenti</a>
 							</div>
						</div>
 						<h2 class="sr-only">Menu principale</h2>
						<ul class="nav navmenu">
							<li><a href="index.html" title="Vai alla pagina: Home" class="current">Home</a></li>
							<li><a href="amministrazione.html" title="Vai alla pagina: Amministrazione">Amministrazione</a></li>
							<li><a href="servizi.html" title="Vai alla pagina: Servizi">Servizi</a></li>
							<li><a href="novita.html" title="Vai alla pagina: Novità">Novità</a></li>
							<li><a href="documenti.html" title="Vai alla pagina: Documenti e dati">Documenti e dati</a></li>
						</ul>
 						<ul class="utilitymobile">
							<li><a href="argomento_cultura.html" title="Vai alla pagina: Cultura">Cultura</a></li>
							<li><a href="#" title="Vai alla pagina: Sport">Sport</a></li>
							<li><a href="#" title="Vai alla pagina: Turismo">Turismo</a></li>
							<li><a href="argomenti.html" title="Vai alla pagina: Argomenti">Tutti gli argomenti</a></li>
						</ul>
 						<ul class="list-inline socialmobile">
							<li class="small">Seguici su</li>
 							<li class=""><a target="_blank" aria-label="Collegamento a sito esterno - Twitter - nuova finestra" href="https://twitter.com/Comune_Cagliari" title="Seguici su Twitter"><svg class="icon"><use xlink:href="static/img/ponmetroca.svg#ca-twitter"></use></svg><span class="hidden">Seguici su Twitter</span></a></li>
 							<li><a target="_blank" aria-label="Collegamento a sito esterno - Facebook - nuova finestra" href="https://www.facebook.com/comunecagliarinews.it" title="Seguici su Facebook"><svg class="icon"><use xlink:href="static/img/ponmetroca.svg#ca-facebook"></use></svg><span class="hidden">Seguici su Facebook</span></a></li>
 							<li><a target="_blank" aria-label="Collegamento a sito esterno - YouTube - nuova finestra" href="https://www.youtube.com/user/ComuneCagliariNews" title="Seguici su YouTube"><svg class="icon"><use xlink:href="static/img/ponmetroca.svg#ca-youtube"></use></svg><span class="hidden">Seguici su YouTube</span></a></li>
							<li><a target="_blank" aria-label="Collegamento a sito esterno - Telegram - nuova finestra" href="https://telegram.me/comunecagliari" title="Seguici su Telegram"><svg class="icon"><use xlink:href="static/img/ponmetroca.svg#ca-telegram"></use></svg><span class="hidden">Seguici su Telegram</span></a></li>
							<li><a target="_blank" aria-label="Collegamento a sito esterno - Whatsapp - nuova finestra" href="tel:+393290582872" title="Contattaci su WhatApp"><svg class="icon"><use xlink:href="static/img/ponmetroca.svg#ca-whatsapp"></use></svg><span class="hidden">Contattaci su WhatApp</span></a></li>
						</ul>

						<!-- accedi -->
						<div class="accedi float-left text-right">									
							<a class="btn-accedi" href="https://www.comune.bari.it/accedi">
								<svg class="icon"><use xlink:href="static/img/ponmetroca.svg#ca-account_circle"></use></svg>
								<span>Nome Cognome</span>
							</a>
						</div>
						<!-- accedi -->
					</div>
 				</nav>
 				<!-- End Menu -->
				<!-- Intestazione -->
				<div class="container header" data-ng-controller="ctrlRicerca as ctrl">
					<div class="row clearfix">
						<div class="col-xl-7 col-lg-7 col-md-8 col-sm-12 comune">
							<div class="logoprint">
								<h1><img src="static/img/logo_comune_di_bari.png" alt="Logo del Portale Impiegati - Gestione Contribuenti"/>Portale Impiegati - Gestione Contribuenti</h1>
							</div>
							<div class="logoimg">
								<a href="index.html" title="Portale Impiegati - Gestione Contribuenti"> 
									<img src="static/img/logo_comune_di_bari.png" alt="Logo del Portale Impiegati - Gestione Contribuenti"/>
								</a>
							</div>
							<div class="logotxt">
								<h1>
									<a href="index.html" title="Portale Impiegati - Gestione Contribuenti">Portale Impiegati - Gestione Contribuenti</a>
								</h1>
							</div>
							<!-- pulsante ricerca mobile -->
							<div class="p_cercaMobile clearfix">
								<button aria-label="Cerca" class="btn btn-default btn-cerca pull-right" data-target="#searchModal" data-toggle="modal" type="button">
									<svg class="icon"><use xlink:href="static/img/ponmetroca.svg#ca-search"></use></svg>
								</button>
							</div>
							<!-- pulsante ricerca mobile -->
						</div>
						<div class="col-xl-3 col-lg-3 d-none d-lg-block d-md-none pull-right text-right">
						</div>
						<div class="col-xl-2 col-lg-2 col-md-4 d-none d-md-block d-md-none text-right">
							<!-- ricerca -->
							<div class="cerca float-right">
								<span>Cerca</span>
								<button aria-label="Cerca" class="btn btn-default btn-cerca pull-right" type="button" data-toggle="modal" data-target="#searchModal">
									<svg class="icon"><use xlink:href="static/img/ponmetroca.svg#ca-search"></use></svg>
								</button>
							</div>
							<!-- ricerca -->
						</div>
					</div>
				</div>
				<!-- Intestazione -->
				<section class="hidden-xs" id="sub_nav">
                    <h2 class="sr-only">Submenu</h2>
                    <div class="container">
                        <div class="row">
                            <div class="col-lg-6 col-md-8 pull-left text-left">
                                <ul class="sub_nav clearfix">
									<li>
									  <a href="amministrazione.html" title="Vai alla pagina: Amministrazione">
										Amministrazione
									  </a>
									</li>
									<li>
									  <a href="servizi.html" title="Vai alla pagina: Servizi">
										Servizi
									  </a>
									</li>
									<li>
									  <a href="novita.html" title="Vai alla pagina: Novità">
										Novità
									  </a>
									</li>
									<li>
									  <a href="documenti.html" title="Vai alla pagina: Documenti e dati">
										Documenti e dati
									  </a>
									</li>
								</ul>
				            </div>
				            <div class="col-lg-6 col-md-4 pull-right text-right">
				                <ul class="list_link-utili">
									<li><a href="argomento_cultura.html" title="Vai alla pagina: Cultura">Cultura</a></li>
									<li><a href="#" title="Vai alla pagina: Sport">Sport</a></li>
									<li><a href="#" title="Vai alla pagina: Turismo">Turismo</a></li>
									<li><a href="argomenti.html" title="Vai alla pagina: Argomenti">Tutti gli argomenti</a></li>
				                </ul>
				            </div>
				        </div>
                    </div>
                </section>
			</header>
			<main id="main_container">
				
				<section id="home-novita">
                    <div class="container">
						<?php
							// 0. estrazione parametro (passato tramite metodo get) da array associativo
							if(isset($_GET["filtro"])){
								$filtro=$_GET["filtro"];
								$par_OK = true;
							}else{
								echo "<h5>Pagina non caricata correttamente.</h5>";
								//exit;
								$par_OK = false;
							}
							
							if($par_OK){
							// 1. info server DB e DB stesso
							$host = "localhost";
							$user = "viabernardocaldarulo";
							$password = "";
							$db = "my_viabernardocaldarulo";
							
							// 2. connessione al server DB 
							$connect = new mysqli($host, $user, $password);
							if ($connect->connect_error)
							{
								die("Errore connessione: " . $connect->connect_error);
							}
							
							// 3. scelta del DB
							if($connect->select_db($db) == 0)
							{
								echo("Il database non esiste");
								exit;
							}
							
							// 4. scrittura della query in base al filtro specificato
							switch($filtro)
							{
								case "merito":
									$sql = "select distinct idFamiglia, cognomeCapofamiglia, nomeCapofamiglia, codiceFiscale, dataNascita, indirizzo, email, telefono, superficie, nComponenti, codiceDispositivo 
											from famiglie, tasse 
											where idFamiglia=codFamiglia and 
												  merito=true
											order by cognomeCapofamiglia, nomeCapofamiglia, codiceFiscale";
									break;
								
								case "demerito":
									$sql = "select distinct idFamiglia, cognomeCapofamiglia, nomeCapofamiglia, codiceFiscale, dataNascita, indirizzo, email, telefono, superficie, nComponenti, codiceDispositivo 
											from famiglie, tasse 
											where idFamiglia=codFamiglia and 
												  merito=false
											order by cognomeCapofamiglia, nomeCapofamiglia, codiceFiscale";
									break;
								
								default:
									$sql = "select distinct idFamiglia, cognomeCapofamiglia, nomeCapofamiglia, codiceFiscale, dataNascita, indirizzo, email, telefono, superficie, nComponenti, codiceDispositivo  
											from famiglie, tasse 
											where idFamiglia=codFamiglia
											order by cognomeCapofamiglia, nomeCapofamiglia, codiceFiscale";
									break;
							}
							
							
							//5. esecuzione della query 
							$result = $connect->query($sql);
						    
							echo "<h5>Filtro di ricerca: ".$filtro."</h5>";
							
							//6. gestione del result set ed eventuale visualizzazione 
							if ($result->num_rows > 0) 
							{
								echo "<table class='table table-striped table-hover'>";
								echo "<tr><th>#</th><th>Cognome</th><th>Nome</th><th>codiceFiscale</th><th>Data di Nascita</th><th>Indirizzo</th><th>Email</th><th>Telefono</th><th>Superficie</th><th>Componenti</th><th>Codice Dispositivo</th></tr>";
								$cont=0;
								while($record = $result->fetch_assoc())
								{ 
									$cont++;
									echo "<tr> ";
										echo "<td>";						
											echo "<a href='dettaglio_contribuenti.php?filtro=".$filtro."&famiglia=".$record["idFamiglia"]."'>$cont</a>";						
										echo "</td>";									
										echo "<td>".$record["cognomeCapofamiglia"]."</td>";
										echo "<td>".$record["nomeCapofamiglia"]."</td>";
										echo "<td>".$record["codiceFiscale"]."</td>";
										echo "<td>".date("d-m-Y", strtotime($record["dataNascita"]))."</td>";										
										echo "<td>".$record["indirizzo"]."</td>";										
										echo "<td>".$record["email"]."</td>";						
										echo "<td>".$record["telefono"]."</td>";
										echo "<td>".$record["superficie"]."</td>";
										echo "<td>".$record["nComponenti"]."</td>";
										echo "<td>".$record["codiceDispositivo"]."</td>";
									echo "</tr>";
								}
								echo "</table>";
							}
							else
							{
								echo "<h5>Nessun contribuente risponde ai filtri indicati. Riprovare o rivolgersi a un superiore.</h5>";
							}
							
							//7. chiusura connessione col DBMS
							$connect->close();	
							echo "<p><a href='#' onClick='history.back();'>Indietro</a></p>";	
							}
						?>	
	                </div>
				</section>				
			</main>
			
		</div>
		<div id="topcontrol" class="topcontrol bg-bluscuro" title="Torna su">
			<svg class="icon"><use xlink:href="static/img/bootstrap-italia.svg#it-collapse"></use></svg>
		</div>
		<link href="static/css/jquery-ui.css" rel="stylesheet" type="text/css" />
		<link href="static/css/owl.carousel.min.css" rel="stylesheet" type="text/css" />
		<link href="static/css/owl.theme.default.min.css" rel="stylesheet" type="text/css" />
		<link href="static/css/home.min.css" rel="stylesheet" type="text/css" />
		<link href="static/css/angular-material.min.css" rel="stylesheet" type="text/css" />
		<script src="static/js/jquery-3.3.1.min.js"></script>
		<script src="static/js/popper.min.js"></script>
		<script>window.__PUBLIC_PATH__ = 'static/font'</script>
		<script src="static/js/bootstrap-italia_1.2.0.min.js"></script>
		<script src="static/js/cagliari.min.js"></script>
		<script src="static/js/jquery-ui.js"></script>
		<script src="static/js/i18n/datepicker-it.js"></script>
		<script src="static/js/angular.min.js"></script>
		<script src="static/js/angular-animate.min.js"></script>
		<script src="static/js/angular-aria.min.js"></script>
		<script src="static/js/angular-messages.min.js"></script>
		<script src="static/js/angular-sanitize.min.js"></script>
		<script src="static/js/app.js"></script>
		<script src="static/js/ricerca.js"></script>
		<script src="static/js/ricerca-service.js"></script>
		<script src="static/js/general-service.js"></script>
		<script src="static/js/angular-material.min.js"></script>
		<script src="static/js/filtri-controller.js"></script>
		<script src="static/js/general-service.js"></script>
		<script src="static/js/filtri-service.js"></script>
		<script src="static/js/owl.carousel.min.js"></script>

		<!-- COOKIE BAR -->
		<div class="cookiebar hide bg-bluscuro" aria-hidden="true">
			<p class="text-white">
				Questo sito utilizza cookie tecnici, analytics e di terze parti. Proseguendo nella navigazione accetti l’utilizzo dei cookie.<br />
				<button data-accept="cookiebar" class="btn btn-info mr-2 btn-verde">Accetto</button>
				<a href="#" class="btn btn-outline-info btn-trasp">Privacy policy</a>
			</p>
		</div>


	</body>
</html>